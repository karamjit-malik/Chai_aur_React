import React from "react";

function Footer()
{
    return(
        <p className="fixed bottom-4 left-1/2 -translate-x-1/2 -z-1">&copy; 2023 AnimeWorld. All rights reserved.</p>
    )
}

export default Footer;